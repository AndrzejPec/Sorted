if not BetterSorting then
  BetterSorting = {}
end

if BetterSorting._fluidDynamicPatch then
  return
end

local THROTTLE_MS = 1000
local lastApplyTime = 0
local ALCOHOL_STRENGTH_THRESHOLD = 10

local function getAlcoholCategoryDetailed(fluidContainer)
  if not fluidContainer or not fluidContainer.isCategory or not fluidContainer:isCategory(FluidCategory.Alcoholic) then
    return nil
  end

  local isMixture = fluidContainer.isMixture and fluidContainer:isMixture()

  if not isMixture then
    local primaryFluid = fluidContainer.getPrimaryFluid and fluidContainer:getPrimaryFluid()
    if primaryFluid then
      local fluidType = primaryFluid.getFluidTypeString and string.lower(primaryFluid:getFluidTypeString())

      if fluidType and string.find(fluidType, "beer", 1, true) then
        return "FoodAB"
      elseif fluidType and (string.find(fluidType, "wine", 1, true) or string.find(fluidType, "mead", 1, true)) then
        return "FoodAW"
      else
        return "FoodAL"
      end
    end
  else
    local totalAlcohol = fluidContainer.getProperties and fluidContainer:getProperties():getAlcohol() or 0
    local totalAmount = fluidContainer.getAmount and fluidContainer:getAmount() or 0

    if totalAmount > 0 then
      local effectivePercentage = (totalAlcohol / totalAmount) * 100

      if effectivePercentage >= ALCOHOL_STRENGTH_THRESHOLD then
        return "FoodAD"
      else
        return "FoodABev"
      end
    end
  end

  return "FoodA"
end

local function getAlcoholCategorySimple(fluidContainer)
  if not fluidContainer or not fluidContainer.isCategory or not fluidContainer:isCategory(FluidCategory.Alcoholic) then
    return nil
  end
  return "FoodA"
end

local function getAlcoholCategory(fluidContainer, detailed)
  if detailed then
    return getAlcoholCategoryDetailed(fluidContainer)
  else
    return getAlcoholCategorySimple(fluidContainer)
  end
end

local function getDynamicFluidCategory(fluidContainer, item)
  if item and item.getEvolvedRecipeName then
    local evolvedRecipeName = item:getEvolvedRecipeName()
    if evolvedRecipeName and evolvedRecipeName ~= "" then
      return "FoodD"
    end
  end

  if not fluidContainer or not fluidContainer.getAmount then
    return nil
  end

  local amount = fluidContainer:getAmount()
  if not amount or amount <= 0 then
    return nil
  end

  if fluidContainer.isCategory and fluidContainer:isCategory(FluidCategory.Fuel) then
    return "Fuel"
  end

  local primary = fluidContainer and fluidContainer.getPrimaryFluid and fluidContainer:getPrimaryFluid()
  local name = primary and primary.getFluidTypeString and string.lower(primary:getFluidTypeString())
  if (name and string.find(name, "milk", 1, true))
      or (fluidContainer.isPureFluid and fluidContainer:isPureFluid(Fluid.AnimalMilk))
      or (fluidContainer.isPureFluid and fluidContainer:isPureFluid(Fluid.SheepMilk))
      or (fluidContainer.isPureFluid and fluidContainer:isPureFluid(Fluid.CowMilk)) then
    return "FoodM"
  end

  local alcoholCategory = getAlcoholCategory(fluidContainer, true)
  if alcoholCategory then
    return alcoholCategory
  end

  if fluidContainer and fluidContainer.isAllCategory and fluidContainer:isAllCategory(FluidCategory.Water) then
    return "FoodW"
  end

  if fluidContainer.isCategory and fluidContainer:isCategory(FluidCategory.Beverage) then
    return "FoodB"
  end

  return nil
end

function BetterSorting.ApplyFluidCategory(item)
  if not item or not item.getFluidContainer or not item.setDisplayCategory then
    return
  end

  local fluidContainer = item:getFluidContainer()
  if not fluidContainer then
    return
  end

  local fullType = item and item.getFullType and item:getFullType()
  local userCategory = nil
  if Sorted and Sorted.getSavedCategory then
    userCategory = Sorted.getSavedCategory(fullType)
  end

  local dynamicCategory = getDynamicFluidCategory(fluidContainer, item)

  if dynamicCategory then
    if item and item.setDisplayCategory then
      item:setDisplayCategory(dynamicCategory)
    end
  elseif userCategory and userCategory ~= "none" then
    if item and item.setDisplayCategory then
      item:setDisplayCategory(userCategory)
    end
  else
    local amount = fluidContainer and fluidContainer.getAmount and fluidContainer:getAmount() or 0
    if amount <= 0 then
      if item and item.setDisplayCategory then
        item:setDisplayCategory("Container")
      end
    end
  end
end

local function applyFluidCategoriesToAllInventories()
  local player = getPlayer()
  if not player then
    return
  end

  local playerInv = player:getInventory()
  if playerInv then
    local items = playerInv:getItems()
    for i = 0, items:size() - 1 do
      BetterSorting.ApplyFluidCategory(items:get(i))
    end
  end
end

if Events and Events.OnRefreshInventoryWindowContainers then
  Events.OnRefreshInventoryWindowContainers.Add(applyFluidCategoriesToAllInventories)
  BetterSorting._fluidDynamicPatch = true
  if Sorted and Sorted.log then
    Sorted:log("FluidDynamicPatch: INSTANT refresh registered (OnRefreshInventoryWindowContainers)", 3)
  end
end

local function applyFluidWithThrottle()
  local now = getTimestampMs()
  if (now - lastApplyTime) < THROTTLE_MS then
    return
  end
  lastApplyTime = now
  applyFluidCategoriesToAllInventories()
end

if Events and Events.OnPlayerUpdate then
  Events.OnPlayerUpdate.Add(applyFluidWithThrottle)
  if Sorted and Sorted.log then
    Sorted:log("FluidDynamicPatch: BACKUP refresh registered (OnPlayerUpdate 1s throttle)", 3)
  end
else
  if Sorted and Sorted.log then
    Sorted:log("OnPlayerUpdate event not found!", 2)
  end
end
